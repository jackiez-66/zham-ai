# Zham.AI — Flutter Source Code

> **AI Nutrisi, Analisis Gizi, dan Asisten Pola Makan Pintar**

Source code Flutter ini adalah starting point untuk membangun Zham.AI sebagai aplikasi Android/iOS yang sesungguhnya. Ikuti langkah-langkah di bawah untuk mendapatkan file APK yang bisa diinstal di HP.

---

## Apa yang sudah ada di source code ini

| Komponen | Status | Keterangan |
|---|---|---|
| Semua layar (Auth, Home, Chat, Proyek, Premium, Profil, Jadwal Makan) | ✅ Lengkap | |
| Navigasi drawer & routing | ✅ Lengkap | |
| Analisis foto makanan (AI Vision) | ✅ Berfungsi | Butuh API key Anthropic |
| Chat nutrisi AI | ✅ Berfungsi | Butuh API key Anthropic |
| Generate jadwal makan mingguan AI | ✅ Berfungsi | Butuh API key Anthropic |
| Batas harian 3 interaksi (Free plan) | ✅ Lengkap | |
| Paywall popup | ✅ Lengkap | |
| Ganti bahasa (Indonesia/English/Melayu) | ✅ Lengkap | |
| Ganti warna aksen | ✅ Lengkap | |
| Simpan data lokal (SharedPreferences) | ✅ Lengkap | |
| Login/Register (mock) | ⚙️ Simulasi | Perlu Firebase Auth untuk produksi |
| Upgrade Premium (mock) | ⚙️ Simulasi | Perlu Midtrans/Xendit untuk produksi |
| Backend Node.js + PostgreSQL | ❌ Belum ada | Perlu dibangun terpisah |

---

## Langkah 1 — Install Flutter

1. Buka **https://flutter.dev/docs/get-started/install** dan pilih platform Anda (Windows/Mac/Linux)
2. Ikuti panduan instalasi Flutter SDK
3. Buka terminal, jalankan:
   ```bash
   flutter doctor
   ```
4. Pastikan semua centang hijau, terutama:
   - ✅ Flutter
   - ✅ Android toolchain (atau ✅ Xcode untuk iOS)
   - ✅ Android Studio / VS Code

---

## Langkah 2 — Buka project ini

```bash
# Masuk ke folder project
cd zham_ai_flutter

# Install semua package yang dibutuhkan
flutter pub get
```

---

## Langkah 3 — Isi API Key Anthropic

Buka file `lib/config.dart` dan isi API key Anda:

```dart
static const String anthropicApiKey = 'sk-ant-api03-XXXXXX...';
```

Dapatkan API key di: **https://console.anthropic.com**

> ⚠️ **Jangan commit API key ke Git publik!**
> Tambahkan `.env` atau `lib/config.dart` ke `.gitignore` untuk keamanan.

---

## Langkah 4 — Tambahkan izin Android

Buka file `android/app/src/main/AndroidManifest.xml` dan tambahkan izin berikut **sebelum tag `<application>`**:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
```

---

## Langkah 5 — Jalankan di emulator atau HP

```bash
# Lihat daftar perangkat yang tersambung
flutter devices

# Jalankan di perangkat tertentu (contoh: emulator-5554)
flutter run -d emulator-5554

# Atau langsung run ke HP yang terhubung USB
flutter run
```

---

## Langkah 6 — Build APK untuk Android

```bash
# Build APK release (siap distribusi)
flutter build apk --release

# File APK tersimpan di:
# build/app/outputs/flutter-apk/app-release.apk
```

Kirim file `app-release.apk` ini ke HP Android Anda untuk diinstal.

---

## Langkah 7 (Opsional) — Build untuk iOS

```bash
# Hanya bisa di komputer Mac dengan Xcode
flutter build ios --release
```

Untuk publish ke App Store, perlu akun **Apple Developer Program** (USD 99/tahun).

---

## Struktur Folder

```
lib/
├── main.dart              ← Entry point app
├── config.dart            ← API key & konfigurasi
├── theme.dart             ← Warna (#8B0000, #121212) & font
├── models.dart            ← Model data (UserProfile, NutritionResult, dll)
├── i18n.dart              ← Terjemahan Indonesia/English/Melayu
├── app_state.dart         ← State management (ChangeNotifier/Provider)
├── services/
│   ├── ai_service.dart    ← Panggilan Claude API (analisis + jadwal makan)
│   └── storage_service.dart ← Simpan data lokal (SharedPreferences)
├── screens/
│   ├── auth_screen.dart   ← Login & Register
│   ├── home_screen.dart   ← Beranda + quick tiles
│   ├── chat_screen.dart   ← Chat AI + analisis foto
│   ├── projects_screen.dart ← Riwayat analisis tersimpan
│   ├── premium_screen.dart  ← Halaman paket Premium
│   ├── profile_screen.dart  ← Pengaturan akun & profil
│   └── meals_screen.dart    ← Jadwal makan mingguan (Premium Plus)
└── widgets/
    ├── z_logo.dart        ← Logo Zham.AI (custom painted)
    ├── z_drawer.dart      ← Navigation drawer
    ├── analysis_card.dart ← Kartu hasil analisis nutrisi
    └── paywall_dialog.dart ← Popup batas harian
```

---

## Untuk Produksi (Setelah MVP)

### Backend yang perlu dibangun
Sesuai blueprint, stack yang direkomendasikan:

| Komponen | Teknologi | Fungsi |
|---|---|---|
| Backend API | Node.js + Express | Proxy ke Claude API (lindungi API key) |
| Database | PostgreSQL | Simpan user, proyek, jadwal makan |
| Auth | Firebase Authentication | Login Gmail sungguhan |
| Payment | Midtrans atau Xendit | Subscription Rp48.000/Rp62.000 |
| Cloud | Firebase Cloud / Supabase | Sync data antar perangkat |

### Alternatif lebih cepat: Supabase
Supabase bisa menggantikan Node.js + PostgreSQL + Firebase Auth sekaligus:
- Auth bawaan (termasuk OAuth Gmail)
- Database PostgreSQL hosted
- Real-time sync
- Gratis untuk MVP
- Dokumentasi: **https://supabase.com/docs**

---

## Fonts (Opsional tapi Direkomendasikan)

Tambahkan font berikut untuk tampilan persis seperti prototype:
1. Download **Space Grotesk** dari Google Fonts
2. Download **IBM Plex Mono** dari Google Fonts
3. Tambahkan ke folder `assets/fonts/`
4. Daftarkan di `pubspec.yaml`:

```yaml
flutter:
  fonts:
    - family: SpaceGrotesk
      fonts:
        - asset: assets/fonts/SpaceGrotesk-Regular.ttf
        - asset: assets/fonts/SpaceGrotesk-SemiBold.ttf weight: 600
        - asset: assets/fonts/SpaceGrotesk-Bold.ttf weight: 700
    - family: IBMPlexMono
      fonts:
        - asset: assets/fonts/IBMPlexMono-Regular.ttf
```

5. Update `lib/theme.dart`, ganti `fontFamily: 'Roboto'` dengan `fontFamily: 'SpaceGrotesk'`

---

## Troubleshooting Umum

**`flutter pub get` gagal**
→ Pastikan koneksi internet aktif dan Flutter SDK sudah benar di PATH.

**Kamera tidak minta izin**
→ Pastikan izin sudah ditambahkan di `AndroidManifest.xml` (lihat Langkah 4).

**AI tidak merespons**
→ Cek API key di `lib/config.dart`. Pastikan tidak ada spasi extra.

**Build APK gagal karena minSdkVersion**
→ Buka `android/app/build.gradle`, set `minSdkVersion 21`.

**`provider` package not found**
→ Jalankan `flutter pub get` lagi di folder project.

---

## Kontak & Pengembangan Lanjut

Source code ini adalah titik awal. Untuk membangun fitur lanjutan (Firebase Auth sungguhan, payment gateway, AI Vision YOLO, database nutrisi Indonesia), dibutuhkan tim developer atau Anda bisa hire freelancer dengan spesifikasi:
- Flutter developer (Android + iOS)
- Node.js backend developer
- Database administrator (PostgreSQL)

---

*Zham.AI © 2026 — "Pahami Nutrisi Makananmu dengan AI Cerdas."*
