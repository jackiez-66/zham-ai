import 'package:flutter/material.dart';

class ZColors {
  static const ink    = Color(0xFF121212);
  static const panel  = Color(0xFF1B1B1D);
  static const raised = Color(0xFF242426);
  static const border = Color(0xFF2B2B2E);
  static const maroon = Color(0xFF8B0000);
  static const ember  = Color(0xFFC81E3A);
  static const gold   = Color(0xFFD4A24C);
  static const ztext  = Color(0xFFF2F0EE);
  static const dim    = Color(0xFF9A9A9E);
  static const faint  = Color(0xFF5F5F63);
  static const good   = Color(0xFF6FCF7C);
}

class ZAccent {
  final String id;
  final String label;
  final Color value;
  final Color glow;
  const ZAccent({required this.id, required this.label, required this.value, required this.glow});
}

const kAccents = [
  ZAccent(id: 'maroon', label: 'Merah Tua', value: ZColors.maroon, glow: ZColors.ember),
  ZAccent(id: 'gold',   label: 'Emas',      value: Color(0xFF9C6B16), glow: ZColors.gold),
  ZAccent(id: 'violet', label: 'Ungu Tua',  value: Color(0xFF5B1A8B), glow: Color(0xFF9D4EDD)),
];

ZAccent accentById(String id) =>
    kAccents.firstWhere((a) => a.id == id, orElse: () => kAccents.first);

ThemeData buildZhamTheme(ZAccent accent) {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: ZColors.ink,
    colorScheme: ColorScheme.fromSeed(
      seedColor: accent.value,
      brightness: Brightness.dark,
      surface: ZColors.panel,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: ZColors.ink,
      elevation: 0,
      foregroundColor: ZColors.ztext,
      centerTitle: true,
    ),
    cardColor: ZColors.panel,
    dividerColor: ZColors.border,
    drawerTheme: const DrawerThemeData(backgroundColor: ZColors.panel),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: ZColors.raised,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: ZColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: ZColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: accent.value, width: 1.4),
      ),
      hintStyle: const TextStyle(color: ZColors.faint, fontSize: 14),
    ),
    textTheme: const TextTheme(
      bodyMedium: TextStyle(color: ZColors.ztext),
      bodySmall:  TextStyle(color: ZColors.dim),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButtonStyle(accent),
    ),
  );
}

class ElevatedButtonStyle extends ButtonStyle {
  ElevatedButtonStyle(ZAccent accent)
      : super(
          backgroundColor: WidgetStateProperty.all(accent.value),
          foregroundColor: WidgetStateProperty.all(Colors.white),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          minimumSize: WidgetStateProperty.all(const Size(double.infinity, 48)),
        );
}
