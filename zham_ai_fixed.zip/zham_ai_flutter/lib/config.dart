/// =========================================================================
/// ZHAM.AI — Configuration
/// =========================================================================
/// Isi API key Anthropic Anda di sini untuk tahap development / MVP.
///
/// ⚠️  PERINGATAN PRODUKSI:
///   Jangan pernah commit API key ke Git repository publik.
///   Untuk produksi, hapus [anthropicApiKey] dari sini dan ganti
///   [useBackendProxy] menjadi true, lalu isi [backendBaseUrl] dengan
///   URL backend Node.js Anda sendiri yang meneruskan request ke Anthropic.
///
/// Cara mendapatkan API key: https://console.anthropic.com
/// =========================================================================

class AppConfig {
  /// Isi dengan API key Anthropic Anda:
  ///   'sk-ant-api03-xxxxxxxxxxxxxxxxxxxx...'
  static const String anthropicApiKey = 'ISI_API_KEY_ANTHROPIC_DI_SINI';

  /// Set true jika Anda sudah punya backend proxy sendiri.
  /// Saat false, request langsung ke api.anthropic.com (hanya untuk dev).
  static const bool useBackendProxy = false;

  /// URL backend Node.js Anda (aktif hanya jika [useBackendProxy] = true).
  /// Contoh: 'https://api.zham.ai' atau 'http://10.0.2.2:3000' untuk emulator.
  static const String backendBaseUrl = 'https://api.zham.ai';

  /// Nama aplikasi dan versi
  static const String appName = 'Zham.AI';
  static const String appVersion = '1.0.0';

  /// Harga langganan (tampilan saja; pembayaran nyata butuh Midtrans/Xendit)
  static const String pricePremium = 'Rp48.000';
  static const String pricePremiumPlus = 'Rp62.000';
}
