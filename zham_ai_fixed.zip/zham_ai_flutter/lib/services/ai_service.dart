import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models.dart';
import '../config.dart';

/// Panggil Anthropic API langsung dari Flutter (untuk development / MVP).
/// PENTING: Untuk produksi, JANGAN simpan API key di kode Flutter.
/// Set AppConfig.useBackendProxy = true dan isi backendBaseUrl.
class AIService {
  static final String _apiKey = AppConfig.anthropicApiKey;
  static const String _baseUrl = 'https://api.anthropic.com/v1/messages';
  static const String _model = 'claude-sonnet-4-6';

  static const _langNames = {
    'id': 'Indonesia', 'en': 'English', 'ms': 'Melayu', 'other': 'Indonesia',
  };

  String _analysisSystemPrompt(String lang) {
    final langName = _langNames[lang] ?? 'Indonesia';
    return '''Kamu adalah Zham.AI, asisten analisis gizi cerdas. Identifikasi makanan dari foto atau deskripsi teks, lalu kembalikan estimasi nutrisi HANYA dalam format JSON valid, tanpa teks lain, tanpa markdown.

Skema JSON wajib:
{
  "items": [{"emoji":"emoji","name":"nama + porsi","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number,"cholesterol_mg":number,"notes":"fakta gizi singkat"}],
  "total": {"calories":number,"protein_g":number,"carbs_g":number,"fat_g":number,"minerals":["maks 4"],"vitamins":["maks 4"],"water_ml":number,"score":integer 0-100},
  "assessment": "1-3 kalimat suportif, satu kelebihan + satu saran"
}

Jika bukan makanan, kembalikan JSON valid dengan "items":[] dan "assessment" menjelaskannya.
Tulis SEMUA teks dalam bahasa: $langName.''';
  }

  String _mealPlanSystemPrompt(String lang) {
    final langName = _langNames[lang] ?? 'Indonesia';
    return '''Kamu adalah Zham.AI, asisten perencana pola makan. Buat rencana makan mingguan (Senin-Minggu) seimbang untuk dewasa aktif. Kembalikan HANYA JSON valid, tanpa teks lain.

Skema JSON wajib:
{"days":[{"day":"nama hari","meals":[{"time":"HH:MM","name":"nama menu","calories":number}]}],"note":"1-2 kalimat catatan"}

Tepat 7 hari, 3-4 meals per hari. Tulis SEMUA teks dalam bahasa: $langName.''';
  }

  Future<Map<String,dynamic>> _call(String systemPrompt, List<Map<String,dynamic>> content) async {
    final res = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': _model,
        'max_tokens': 1000,
        'system': systemPrompt,
        'messages': [{'role': 'user', 'content': content}],
      }),
    );
    if (res.statusCode != 200) throw Exception('API error: ${res.statusCode}');
    final data = jsonDecode(res.body) as Map<String,dynamic>;
    final text = (data['content'] as List)
        .map((b) => b['text'] ?? '')
        .join('\n')
        .replaceAll(RegExp(r'```json|```'), '')
        .trim();
    try {
      return jsonDecode(text) as Map<String,dynamic>;
    } catch (_) {
      final match = RegExp(r'\{[\s\S]*\}').firstMatch(text);
      if (match != null) return jsonDecode(match.group(0)!) as Map<String,dynamic>;
      rethrow;
    }
  }

  Future<NutritionResult> analyzeText(String text, String lang) async {
    final json = await _call(_analysisSystemPrompt(lang), [
      {'type': 'text', 'text': text}
    ]);
    return NutritionResult.fromJson(json);
  }

  Future<NutritionResult> analyzeImage(Uint8List imageBytes, String mimeType, String lang) async {
    final b64 = base64Encode(imageBytes);
    final json = await _call(_analysisSystemPrompt(lang), [
      {'type': 'image', 'source': {'type': 'base64', 'media_type': mimeType, 'data': b64}},
      {'type': 'text', 'text': 'Analisis kandungan gizi makanan pada foto ini.'},
    ]);
    return NutritionResult.fromJson(json);
  }

  Future<MealPlan> generateMealPlan(String lang) async {
    final json = await _call(_mealPlanSystemPrompt(lang), [
      {'type': 'text', 'text': 'Buat rencana makan mingguan.'}
    ]);
    return MealPlan.fromJson(json);
  }
}
