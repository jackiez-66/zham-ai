import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models.dart';

class StorageService {
  static const _kProfile  = 'zham_profile';
  static const _kUsage    = 'zham_usage';
  static const _kProjects = 'zham_projects';
  static const _kMeals    = 'zham_meals';

  Future<UserProfile?> getProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProfile);
    if (raw == null) return null;
    try { return UserProfile.fromJson(jsonDecode(raw)); } catch (_) { return null; }
  }
  Future<void> setProfile(UserProfile p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProfile, jsonEncode(p.toJson()));
  }
  Future<void> clearProfile() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kProfile);
  }

  String _todayStr() => DateTime.now().toIso8601String().substring(0, 10);

  Future<DailyUsage> getUsage() async {
    final today = _todayStr();
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kUsage);
    if (raw == null) return DailyUsage(date: today, count: 0);
    try {
      final u = DailyUsage.fromJson(jsonDecode(raw));
      return u.date == today ? u : DailyUsage(date: today, count: 0);
    } catch (_) { return DailyUsage(date: today, count: 0); }
  }
  Future<void> setUsage(DailyUsage u) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kUsage, jsonEncode(u.toJson()));
  }

  Future<List<Project>> getProjects() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProjects);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => Project.fromJson(e as Map<String,dynamic>)).toList();
    } catch (_) { return []; }
  }
  Future<void> setProjects(List<Project> projects) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _kProjects,
      jsonEncode(projects.take(50).map((p) => p.toJson()).toList()),
    );
  }

  Future<MealPlan?> getMeals() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kMeals);
    if (raw == null) return null;
    try { return MealPlan.fromJson(jsonDecode(raw)); } catch (_) { return null; }
  }
  Future<void> setMeals(MealPlan? plan) async {
    final prefs = await SharedPreferences.getInstance();
    if (plan == null) { await prefs.remove(_kMeals); return; }
    await prefs.setString(_kMeals, jsonEncode(plan.toJson()));
  }
}
