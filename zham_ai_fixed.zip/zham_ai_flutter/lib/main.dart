import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app_state.dart';
import 'theme.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/projects_screen.dart';
import 'screens/premium_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/meals_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Paksa orientasi portrait (cocok untuk app nutrisi di HP)
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Status bar transparan agar UI menyatu dengan warna gelap
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF121212),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState()..boot(),
      child: const ZhamApp(),
    ),
  );
}

class ZhamApp extends StatelessWidget {
  const ZhamApp({super.key});

  @override
  Widget build(BuildContext context) {
    final accent = context.select<AppState, ZAccent>((s) => s.accent);
    return MaterialApp(
      title: 'Zham.AI',
      debugShowCheckedModeBanner: false,
      theme: buildZhamTheme(accent),
      // Tampilkan splash gelap saat memuat storage sebelum render layar pertama
      home: const _BootGate(),
      routes: {
        '/home':     (_) => const HomeScreen(),
        '/chat':     (_) => const ChatScreen(),
        '/projects': (_) => const ProjectsScreen(),
        '/premium':  (_) => const PremiumScreen(),
        '/profile':  (_) => const ProfileScreen(),
        '/meals':    (_) => const MealsScreen(),
      },
    );
  }
}

/// Menunggu AppState.boot() selesai memuat data lokal, lalu
/// memutuskan apakah tampilkan AuthScreen atau HomeScreen.
class _BootGate extends StatelessWidget {
  const _BootGate();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    // Belum selesai boot — tampilkan layar hitam + loading kecil
    if (!state.booted) {
      return const Scaffold(
        backgroundColor: Color(0xFF121212),
        body: Center(
          child: CircularProgressIndicator(
            color: Color(0xFF8B0000),
            strokeWidth: 2.5,
          ),
        ),
      );
    }

    // Belum login → Auth
    if (state.profile == null) {
      return const AuthScreen();
    }

    // Sudah login → Home
    return const HomeScreen();
  }
}
