import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';
import '../widgets/analysis_card.dart';
import '../widgets/paywall_dialog.dart';

class ChatScreen extends StatefulWidget {
  final String? intent; // 'camera' | 'gallery' | null
  const ChatScreen({super.key, this.intent});
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _picker = ImagePicker();
  final List<_Msg> _messages = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final state = context.read<AppState>();
    final lang = state.profile?.language ?? 'id';
    _messages.add(_Msg.aiText(tr(lang, 'chatGreeting')));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.intent == 'camera') _pickImage(ImageSource.camera);
      if (widget.intent == 'gallery') _pickImage(ImageSource.gallery);
    });
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    final state = context.read<AppState>();
    if (!state.canInteract()) {
      await showPaywallDialog(context, state.profile?.language ?? 'id',
        onUpgrade: () => Navigator.pushReplacementNamed(context, '/premium'));
      return;
    }
    final file = await _picker.pickImage(source: source, maxWidth: 1024, imageQuality: 85);
    if (file == null) return;
    final bytes = await file.readAsBytes();
    await state.registerInteraction();
    setState(() {
      _messages.add(_Msg.userImage(bytes));
      _busy = true;
    });
    _scrollToBottom();
    try {
      final result = await state.analyzeImage(bytes.toList(), 'image/jpeg');
      await state.saveProject(result);
      setState(() { _messages.add(_Msg.analysis(result)); _busy = false; });
    } catch (e) {
      setState(() { _messages.add(_Msg.aiText(tr(state.profile?.language ?? 'id', 'errorAnalysis'))); _busy = false; });
    }
    _scrollToBottom();
  }

  Future<void> _sendText() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty || _busy) return;
    final state = context.read<AppState>();
    if (!state.canInteract()) {
      await showPaywallDialog(context, state.profile?.language ?? 'id',
        onUpgrade: () => Navigator.pushReplacementNamed(context, '/premium'));
      return;
    }
    _textCtrl.clear();
    await state.registerInteraction();
    setState(() { _messages.add(_Msg.userText(text)); _busy = true; });
    _scrollToBottom();
    try {
      final result = await state.analyzeText(text);
      await state.saveProject(result);
      setState(() { _messages.add(_Msg.analysis(result)); _busy = false; });
    } catch (e) {
      setState(() { _messages.add(_Msg.aiText(tr(state.profile?.language ?? 'id', 'errorAnalysis'))); _busy = false; });
    }
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final lang = state.profile?.language ?? 'id';
    final t = (String k) => tr(lang, k);

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/chat'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          Text(t('navNewChat'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.all(16),
            itemCount: _messages.length + (_busy ? 1 : 0),
            itemBuilder: (ctx, i) {
              if (_busy && i == _messages.length) return _LoadingBubble(t: t);
              return _BubbleWidget(msg: _messages[i], accent: accent, lang: lang);
            },
          ),
        ),
        _InputBar(
          ctrl: _textCtrl, busy: _busy, accent: accent, t: t,
          onSend: _sendText,
          onCamera:  () => _pickImage(ImageSource.camera),
          onGallery: () => _pickImage(ImageSource.gallery),
        ),
      ]),
    );
  }
}

// ── Message types ─────────────────────────────────────────────────────────────

class _Msg {
  final String type; // 'ai_text' | 'user_text' | 'user_image' | 'analysis'
  final String? text;
  final List<int>? imageBytes;
  final NutritionResult? data;
  _Msg._({required this.type, this.text, this.imageBytes, this.data});
  factory _Msg.aiText(String t)          => _Msg._(type: 'ai_text',     text: t);
  factory _Msg.userText(String t)        => _Msg._(type: 'user_text',   text: t);
  factory _Msg.userImage(List<int> b)    => _Msg._(type: 'user_image',  imageBytes: b);
  factory _Msg.analysis(NutritionResult d) => _Msg._(type: 'analysis',  data: d);
}

class _BubbleWidget extends StatelessWidget {
  final _Msg msg;
  final ZAccent accent;
  final String lang;
  const _BubbleWidget({required this.msg, required this.accent, required this.lang});

  @override
  Widget build(BuildContext context) {
    final isUser = msg.type == 'user_text' || msg.type == 'user_image';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (msg.type == 'ai_text') ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: ZColors.panel, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: ZColors.border),
              ),
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
              child: Text(msg.text!, style: const TextStyle(color: ZColors.ztext, fontSize: 13.5, height: 1.5)),
            ),
          ] else if (msg.type == 'user_text') ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [accent.glow, accent.value]),
                borderRadius: BorderRadius.circular(14),
              ),
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
              child: Text(msg.text!, style: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.5)),
            ),
          ] else if (msg.type == 'user_image') ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.memory(
                Uint8List.fromList(msg.imageBytes!),
                width: MediaQuery.of(context).size.width * 0.65,
                fit: BoxFit.cover,
              ),
            ),
          ] else if (msg.type == 'analysis') ...[
            Expanded(child: AnalysisCard(data: msg.data!, accent: accent, lang: lang)),
          ],
        ],
      ),
    );
  }
}

class _LoadingBubble extends StatelessWidget {
  final String Function(String) t;
  const _LoadingBubble({required this.t});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: ZColors.panel, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: ZColors.border),
          ),
          child: Row(children: [
            const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: ZColors.dim)),
            const SizedBox(width: 10),
            Text(t('analyzing'), style: const TextStyle(color: ZColors.dim, fontSize: 13)),
          ]),
        ),
      ]),
    );
  }
}

class _InputBar extends StatelessWidget {
  final TextEditingController ctrl;
  final bool busy;
  final ZAccent accent;
  final String Function(String) t;
  final VoidCallback onSend, onCamera, onGallery;
  const _InputBar({required this.ctrl, required this.busy, required this.accent,
    required this.t, required this.onSend, required this.onCamera, required this.onGallery});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
      decoration: const BoxDecoration(
        color: ZColors.ink, border: Border(top: BorderSide(color: ZColors.border)),
      ),
      child: Row(children: [
        _IconBtn(icon: Icons.camera_alt_outlined, onTap: busy ? null : onCamera),
        const SizedBox(width: 6),
        _IconBtn(icon: Icons.image_outlined, onTap: busy ? null : onGallery),
        const SizedBox(width: 8),
        Expanded(
          child: TextField(
            controller: ctrl, enabled: !busy,
            style: const TextStyle(color: ZColors.ztext, fontSize: 13.5),
            onSubmitted: (_) => onSend(),
            decoration: InputDecoration(
              hintText: t('chatHint'), hintStyle: const TextStyle(color: ZColors.faint, fontSize: 13.5),
              filled: true, fillColor: ZColors.raised,
              contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: accent.value, width: 1.4)),
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: busy ? null : onSend,
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [accent.glow, accent.value]),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.send_rounded, color: busy ? Colors.white38 : Colors.white, size: 18),
          ),
        ),
      ]),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _IconBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: ZColors.raised, borderRadius: BorderRadius.circular(10),
          border: Border.all(color: ZColors.border),
        ),
        child: Icon(icon, color: onTap == null ? ZColors.faint : ZColors.ztext, size: 18),
      ),
    );
  }
}
