import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final lang = state.profile?.language ?? 'id';
    final t = (String k) => tr(lang, k);
    final plan = state.profile?.plan ?? ZPlan.free;

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/premium'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          Text(t('navPremium'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t('premiumTitle'), style: const TextStyle(color: ZColors.ztext, fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(t('premiumSub'), style: const TextStyle(color: ZColors.dim, fontSize: 12.5)),
          const SizedBox(height: 20),
          _PlanCard(
            name: 'Zham.AI Premium', price: 'Rp48.000', t: t, accent: accent,
            active: plan == ZPlan.premium,
            onChoose: () => state.upgrade(ZPlan.premium),
            features: const [
              'Model Zham.AI 1.0', 'Analisis lebih detail', 'Unggah gambar lebih banyak',
              'Memori lebih besar', 'Prioritas respons lebih cepat', 'Riwayat proyek lebih panjang',
              'Bebas berinteraksi tanpa batas harian',
              'Bebas mengirim foto, gambar, dan pesan kapan saja',
            ],
          ),
          _PlanCard(
            name: 'Zham.AI Premium Plus', price: 'Rp62.000', t: t, accent: accent,
            active: plan == ZPlan.premiumPlus, highlight: true,
            onChoose: () => state.upgrade(ZPlan.premiumPlus),
            features: const [
              'Semua fitur Premium', 'Model Zham.AI 2.0', 'Mode Penalaran Canggih',
              'Memori jauh lebih besar', 'Akses awal fitur terbaru', 'Jadwal Makan AI Otomatis',
              'Analisis nutrisi lebih mendalam', 'Rekomendasi kesehatan personal',
              'Prioritas server tertinggi', 'Pendamping nutrisi AI yang lebih proaktif',
            ],
          ),
        ]),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String name, price;
  final String Function(String) t;
  final ZAccent accent;
  final bool active, highlight;
  final VoidCallback onChoose;
  final List<String> features;
  const _PlanCard({
    required this.name, required this.price, required this.t, required this.accent,
    required this.active, required this.onChoose, required this.features,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: ZColors.panel, borderRadius: BorderRadius.circular(18),
        border: Border.all(color: highlight ? accent.value : ZColors.border, width: highlight ? 1.5 : 1),
        boxShadow: highlight ? [BoxShadow(color: accent.value.withOpacity(0.2), blurRadius: 20, spreadRadius: 1)] : null,
      ),
      child: Stack(children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.workspace_premium_outlined, color: accent.glow, size: 18),
            const SizedBox(width: 8),
            Text(name, style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700, fontSize: 16)),
          ]),
          const SizedBox(height: 6),
          RichText(text: TextSpan(children: [
            TextSpan(text: price, style: TextStyle(color: ZColors.ztext, fontSize: 22, fontWeight: FontWeight.w700, fontFamily: 'monospace')),
            TextSpan(text: t('perMonth'), style: const TextStyle(color: ZColors.dim, fontSize: 12)),
          ])),
          const SizedBox(height: 14),
          ...features.map((f) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.check, color: accent.glow, size: 16),
              const SizedBox(width: 8),
              Expanded(child: Text(f, style: const TextStyle(color: ZColors.dim, fontSize: 12.5))),
            ]),
          )),
          const SizedBox(height: 4),
          active
              ? Center(child: Text('✓ ${t("currentPlan")}',
                  style: TextStyle(color: accent.glow, fontWeight: FontWeight.w600, fontSize: 13)))
              : SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accent.value, foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: onChoose,
                    child: Text(t('choosePlan'), style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ),
        ]),
        if (highlight) Positioned(
          top: 0, right: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [accent.glow, accent.value]),
              borderRadius: BorderRadius.circular(999),
            ),
            child: const Text('POPULER', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
          ),
        ),
      ]),
    );
  }
}
