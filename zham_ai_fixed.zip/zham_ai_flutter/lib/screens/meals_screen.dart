import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';

class MealsScreen extends StatefulWidget {
  const MealsScreen({super.key});
  @override State<MealsScreen> createState() => _MealsScreenState();
}

class _MealsScreenState extends State<MealsScreen> {
  bool _busy = false;
  bool _showManual = false;
  String _day = 'Senin';
  String _time = '07:00';
  final _nameCtrl = TextEditingController();
  final _calCtrl  = TextEditingController();

  Future<void> _generate(AppState state) async {
    setState(() => _busy = true);
    try { await state.generateMealPlan(); }
    catch (e) { state.showToast(tr(state.profile?.language ?? 'id', 'errorAnalysis')); }
    finally   { setState(() => _busy = false); }
  }

  void _addManual(AppState state) {
    if (_nameCtrl.text.trim().isEmpty || _calCtrl.text.trim().isEmpty) return;
    final plan = state.meals ?? MealPlan.emptyWeek();
    final days = plan.days.map((d) => d.day == _day
        ? MealDay(day: d.day, meals: [...d.meals, MealEntry(time: _time, name: _nameCtrl.text.trim(), calories: double.tryParse(_calCtrl.text) ?? 0)])
        : d).toList();
    state.setMeals(MealPlan(days: days, note: plan.note));
    _nameCtrl.clear(); _calCtrl.clear();
    setState(() => _showManual = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final lang = state.profile?.language ?? 'id';
    final t = (String k) => tr(lang, k);
    final isPremPlus = state.profile?.plan == ZPlan.premiumPlus;

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/meals'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          Text(t('mealsTitle'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
        actions: [
          if (isPremPlus && state.meals != null)
            IconButton(
              icon: const Icon(Icons.add, color: ZColors.ztext),
              onPressed: () => setState(() => _showManual = !_showManual),
            ),
        ],
      ),
      body: !isPremPlus
          ? _LockedView(accent: accent, t: t, context: context)
          : state.meals == null
              ? _EmptyView(accent: accent, t: t, busy: _busy, onGenerate: () => _generate(state),
                  showManual: _showManual, onManual: () => setState(() => _showManual = !_showManual),
                  manualForm: _showManual ? _ManualForm(day: _day, time: _time, nameCtrl: _nameCtrl, calCtrl: _calCtrl,
                    onDayChanged: (v) => setState(() => _day = v),
                    onTimeChanged: (v) => setState(() => _time = v),
                    onSave: () => _addManual(state), t: t, accent: accent) : null)
              : _PlanView(plan: state.meals!, accent: accent, t: t, busy: _busy,
                  onRegen: () => _generate(state),
                  showManual: _showManual,
                  manualForm: _showManual ? _ManualForm(day: _day, time: _time, nameCtrl: _nameCtrl, calCtrl: _calCtrl,
                    onDayChanged: (v) => setState(() => _day = v),
                    onTimeChanged: (v) => setState(() => _time = v),
                    onSave: () => _addManual(state), t: t, accent: accent) : null),
    );
  }
}

class _LockedView extends StatelessWidget {
  final ZAccent accent;
  final String Function(String) t;
  final BuildContext context;
  const _LockedView({required this.accent, required this.t, required this.context});
  @override
  Widget build(BuildContext ctx) {
    return Center(child: Padding(
      padding: const EdgeInsets.all(40),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.lock_outline, color: ZColors.faint, size: 36),
        const SizedBox(height: 14),
        Text(t('featurePremPlus'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700, fontSize: 15), textAlign: TextAlign.center),
        const SizedBox(height: 8),
        Text(t('mealsLocked'), style: const TextStyle(color: ZColors.dim, fontSize: 13, height: 1.5), textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: accent.value, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 20)),
          onPressed: () => Navigator.pushReplacementNamed(context, '/premium'),
          child: Text(t('mealsUpgrade'), style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
      ]),
    ));
  }
}

class _EmptyView extends StatelessWidget {
  final ZAccent accent;
  final String Function(String) t;
  final bool busy, showManual;
  final VoidCallback onGenerate, onManual;
  final Widget? manualForm;
  const _EmptyView({required this.accent, required this.t, required this.busy,
    required this.onGenerate, required this.onManual, required this.showManual, this.manualForm});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(children: [
        const Icon(Icons.calendar_today_outlined, color: ZColors.faint, size: 36),
        const SizedBox(height: 16),
        Text(t('mealsEmpty'), style: const TextStyle(color: ZColors.dim, fontSize: 13, height: 1.6), textAlign: TextAlign.center),
        const SizedBox(height: 22),
        if (busy) ...[
          const CircularProgressIndicator(),
          const SizedBox(height: 10),
          Text(t('mealsGenerating'), style: const TextStyle(color: ZColors.dim, fontSize: 13)),
        ] else ...[
          SizedBox(width: double.infinity, child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: accent.value, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 13)),
            onPressed: onGenerate,
            icon: const Icon(Icons.auto_awesome, size: 16),
            label: Text(t('mealsAuto'), style: const TextStyle(fontWeight: FontWeight.w600)),
          )),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton(
            style: OutlinedButton.styleFrom(foregroundColor: ZColors.ztext,
              side: const BorderSide(color: ZColors.border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 13)),
            onPressed: onManual,
            child: Text(t('mealsManual')),
          )),
        ],
        if (manualForm != null) ...[const SizedBox(height: 16), manualForm!],
      ]),
    );
  }
}

class _PlanView extends StatelessWidget {
  final MealPlan plan;
  final ZAccent accent;
  final String Function(String) t;
  final bool busy, showManual;
  final VoidCallback onRegen;
  final Widget? manualForm;
  const _PlanView({required this.plan, required this.accent, required this.t,
    required this.busy, required this.onRegen, required this.showManual, this.manualForm});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (manualForm != null) ...[manualForm!, const SizedBox(height: 10)],
        if (plan.note.isNotEmpty) ...[
          Text(plan.note, style: const TextStyle(color: ZColors.dim, fontSize: 12, fontStyle: FontStyle.italic)),
          const SizedBox(height: 12),
        ],
        ...plan.days.map((d) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text(d.day.toUpperCase(), style: TextStyle(color: accent.glow, fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 0.8)),
          ),
          if (d.meals.isEmpty) const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text('—', style: TextStyle(color: ZColors.faint, fontSize: 12)),
          ) else ...d.meals.map((m) => Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(color: ZColors.panel, borderRadius: BorderRadius.circular(10), border: Border.all(color: ZColors.border)),
            child: Row(children: [
              SizedBox(width: 44, child: Text(m.time, style: const TextStyle(color: ZColors.dim, fontSize: 12, fontFamily: 'monospace'))),
              Expanded(child: Text(m.name, style: const TextStyle(color: ZColors.ztext, fontSize: 13))),
              Text('${m.calories.round()} kkal', style: const TextStyle(color: ZColors.faint, fontSize: 12, fontFamily: 'monospace')),
            ]),
          )),
          const SizedBox(height: 8),
        ])),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(
          style: OutlinedButton.styleFrom(foregroundColor: ZColors.ztext,
            side: const BorderSide(color: ZColors.border),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 13)),
          onPressed: busy ? null : onRegen,
          icon: busy ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome, size: 15),
          label: Text(t('mealsRegen')),
        )),
      ]),
    );
  }
}

class _ManualForm extends StatelessWidget {
  final String day, time;
  final TextEditingController nameCtrl, calCtrl;
  final void Function(String) onDayChanged, onTimeChanged;
  final VoidCallback onSave;
  final String Function(String) t;
  final ZAccent accent;
  const _ManualForm({required this.day, required this.time, required this.nameCtrl,
    required this.calCtrl, required this.onDayChanged, required this.onTimeChanged,
    required this.onSave, required this.t, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: ZColors.panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: ZColors.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t('mealsAddTitle'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 13.5)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: DropdownButtonFormField<String>(
              value: day, dropdownColor: ZColors.raised,
              style: const TextStyle(color: ZColors.ztext, fontSize: 12.5),
              decoration: InputDecoration(filled: true, fillColor: ZColors.raised,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
              items: MealPlan.weekDays.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
              onChanged: (v) => onDayChanged(v ?? day),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(width: 90, child: TextField(
            readOnly: true, style: const TextStyle(color: ZColors.ztext, fontSize: 12.5),
            decoration: InputDecoration(hintText: time, hintStyle: const TextStyle(color: ZColors.ztext),
              filled: true, fillColor: ZColors.raised,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10)),
            onTap: () async {
              final picked = await showTimePicker(context: context, initialTime: TimeOfDay.now());
              if (picked != null) onTimeChanged('${picked.hour.toString().padLeft(2,"0")}:${picked.minute.toString().padLeft(2,"0")}');
            },
          )),
        ]),
        const SizedBox(height: 8),
        TextField(controller: nameCtrl,
          style: const TextStyle(color: ZColors.ztext, fontSize: 12.5),
          decoration: InputDecoration(hintText: t('mealsName'), filled: true, fillColor: ZColors.raised,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9))),
        const SizedBox(height: 8),
        TextField(controller: calCtrl, keyboardType: TextInputType.number,
          style: const TextStyle(color: ZColors.ztext, fontSize: 12.5),
          decoration: InputDecoration(hintText: t('mealsCal'), filled: true, fillColor: ZColors.raised,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: ZColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9))),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: accent.value, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(vertical: 11)),
          onPressed: onSave,
          child: Text(t('mealsSave'), style: const TextStyle(fontWeight: FontWeight.w600)),
        )),
      ]),
    );
  }
}
