import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';
import '../widgets/analysis_card.dart';

class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});
  @override State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  String? _openId;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final lang = state.profile?.language ?? 'id';
    final t = (String k) => tr(lang, k);
    final projects = state.projects;

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/projects'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          Text(t('navProjects'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
      ),
      body: projects.isEmpty
          ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.folder_open_outlined, color: ZColors.faint, size: 40),
              const SizedBox(height: 14),
              Text(t('emptyProjects'),
                style: const TextStyle(color: ZColors.dim, fontSize: 13),
                textAlign: TextAlign.center),
              const SizedBox(height: 18),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent.value, foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                child: Text(t('ctaStart')),
              ),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: projects.length,
              itemBuilder: (ctx, i) {
                final p = projects[i];
                final isOpen = _openId == p.id;
                return Column(children: [
                  GestureDetector(
                    onTap: () => setState(() => _openId = isOpen ? null : p.id),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: ZColors.panel, borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: ZColors.border),
                      ),
                      child: Row(children: [
                        Text(p.emoji, style: const TextStyle(fontSize: 20)),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(p.title, style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 13.5)),
                          Text('${p.data.total.calories.round()} kkal · ${p.data.total.score.round()} skor',
                            style: const TextStyle(color: ZColors.faint, fontSize: 11.5)),
                        ])),
                        AnimatedRotation(
                          turns: isOpen ? 0.5 : 0,
                          duration: const Duration(milliseconds: 200),
                          child: const Icon(Icons.keyboard_arrow_down, color: ZColors.faint, size: 20),
                        ),
                      ]),
                    ),
                  ),
                  if (isOpen) ...[
                    AnalysisCard(data: p.data, accent: accent, lang: lang),
                    const SizedBox(height: 10),
                  ],
                ]);
              },
            ),
    );
  }
}
