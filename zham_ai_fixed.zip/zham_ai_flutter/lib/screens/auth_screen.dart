import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _firstCtrl = TextEditingController();
  final _lastCtrl  = TextEditingController();
  String _lang = 'id';
  String _error = '';

  void _submit() {
    final state = context.read<AppState>();
    if (_isLogin) {
      if (_emailCtrl.text.trim().isEmpty || _passCtrl.text.trim().isEmpty) {
        setState(() => _error = 'Isi Gmail dan kata sandi terlebih dahulu.'); return;
      }
      final name = _emailCtrl.text.split('@').first;
      state.login(UserProfile(
        firstName: name, lastName: '', email: _emailCtrl.text.trim(), language: 'id',
      ));
    } else {
      if (_firstCtrl.text.trim().isEmpty || _emailCtrl.text.trim().isEmpty || _passCtrl.text.trim().isEmpty) {
        setState(() => _error = 'Nama depan, Gmail, dan kata sandi wajib diisi.'); return;
      }
      state.login(UserProfile(
        firstName: _firstCtrl.text.trim(), lastName: _lastCtrl.text.trim(),
        email: _emailCtrl.text.trim(), language: _lang,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.watch<AppState>().accent;
    const t0 = 'id';
    final t = (String k) => tr(t0, k);
    return Scaffold(
      backgroundColor: ZColors.ink,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(children: [
            ZLogo(size: 56, accent: accent.value, glow: accent.glow),
            const SizedBox(height: 14),
            const Text('Zham.AI',
              style: TextStyle(color: ZColors.ztext, fontSize: 24, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(t('tagline'),
              style: const TextStyle(color: ZColors.dim, fontSize: 13),
              textAlign: TextAlign.center),
            const SizedBox(height: 28),
            // Tab selector
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: ZColors.raised, borderRadius: BorderRadius.circular(12)),
              child: Row(children: [
                _Tab(label: t('authLogin'),    active: _isLogin,  onTap: () => setState(() { _isLogin = true;  _error = ''; }), accent: accent),
                _Tab(label: t('authRegister'), active: !_isLogin, onTap: () => setState(() { _isLogin = false; _error = ''; }), accent: accent),
              ]),
            ),
            const SizedBox(height: 18),
            if (!_isLogin) ...[
              Row(children: [
                Expanded(child: _ZField(label: t('authFirst'), ctrl: _firstCtrl)),
                const SizedBox(width: 10),
                Expanded(child: _ZField(label: t('authLast'), ctrl: _lastCtrl)),
              ]),
            ],
            _ZField(label: t('authEmail'), ctrl: _emailCtrl, keyboardType: TextInputType.emailAddress),
            _ZField(label: t('authPass'), ctrl: _passCtrl, obscure: true),
            if (!_isLogin) ...[
              Align(alignment: Alignment.centerLeft,
                child: Text(t('authLang'), style: const TextStyle(color: ZColors.dim, fontSize: 12))),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _lang,
                dropdownColor: ZColors.raised,
                style: const TextStyle(color: ZColors.ztext),
                decoration: InputDecoration(
                  filled: true, fillColor: ZColors.raised,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                ),
                items: const [
                  DropdownMenuItem(value: 'id', child: Text('Indonesia')),
                  DropdownMenuItem(value: 'en', child: Text('English')),
                  DropdownMenuItem(value: 'ms', child: Text('Melayu')),
                  DropdownMenuItem(value: 'other', child: Text('Lainnya')),
                ],
                onChanged: (v) => setState(() => _lang = v ?? 'id'),
              ),
              const SizedBox(height: 14),
            ],
            if (_error.isNotEmpty) ...[
              Align(alignment: Alignment.centerLeft,
                child: Text(_error, style: TextStyle(color: accent.glow, fontSize: 12.5))),
              const SizedBox(height: 8),
            ],
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent.value,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                onPressed: _submit,
                child: Text(_isLogin ? t('authLoginBtn') : t('authRegBtn'),
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 16),
            Row(children: const [
              Expanded(child: Divider(color: ZColors.border)),
              Padding(padding: EdgeInsets.symmetric(horizontal: 10),
                child: Text('atau', style: TextStyle(color: ZColors.faint, fontSize: 11.5))),
              Expanded(child: Divider(color: ZColors.border)),
            ]),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: ZColors.ztext,
                side: const BorderSide(color: ZColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 13),
                minimumSize: const Size(double.infinity, 0),
              ),
              onPressed: _submit,
              icon: const Icon(Icons.mail_outline, size: 18),
              label: Text(t('authGmail')),
            ),
            const SizedBox(height: 18),
            GestureDetector(
              onTap: () => setState(() { _isLogin = !_isLogin; _error = ''; }),
              child: Text(
                _isLogin ? t('authSwReg') : t('authSwLogin'),
                style: TextStyle(color: accent.glow, fontSize: 12.5),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  final ZAccent accent;
  const _Tab({required this.label, required this.active, required this.onTap, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            gradient: active ? LinearGradient(colors: [accent.glow, accent.value]) : null,
          ),
          child: Text(label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: active ? Colors.white : ZColors.dim,
              fontWeight: FontWeight.w600, fontSize: 13.5,
            )),
        ),
      ),
    );
  }
}

class _ZField extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final bool obscure;
  final TextInputType? keyboardType;
  const _ZField({required this.label, required this.ctrl, this.obscure = false, this.keyboardType});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: ZColors.dim, fontSize: 12)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl, obscureText: obscure, keyboardType: keyboardType,
          style: const TextStyle(color: ZColors.ztext, fontSize: 14.5),
          decoration: InputDecoration(
            filled: true, fillColor: ZColors.raised,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: ZColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
          ),
        ),
      ]),
    );
  }
}
