import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final profile = state.profile!;
    final lang = profile.language;
    final t = (String k) => tr(lang, k);
    final isFree = profile.plan == ZPlan.free;
    final usage = state.usage;
    final recent = state.projects.take(2).toList();

    void goChat({String? intent}) {
      Navigator.pushReplacementNamed(context, '/chat', arguments: intent);
    }

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/home'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          const Text('Zham.AI', style: TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushReplacementNamed(context, '/profile'),
            icon: const CircleAvatar(radius: 15, backgroundColor: ZColors.raised,
              child: Icon(Icons.person_outline, color: ZColors.dim, size: 16)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${t("welcome")} ${profile.firstName} 👋',
            style: const TextStyle(color: ZColors.ztext, fontSize: 21, fontWeight: FontWeight.w700)),
          if (isFree) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: ZColors.panel, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: ZColors.border),
              ),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(t('usageToday'), style: const TextStyle(color: ZColors.dim, fontSize: 12.5)),
                  Text('${usage.count}/3', style: const TextStyle(color: ZColors.ztext, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ]),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: usage.count / 3,
                    backgroundColor: ZColors.raised,
                    valueColor: AlwaysStoppedAnimation(accent.value),
                    minHeight: 6,
                  ),
                ),
              ]),
            ),
          ],
          const SizedBox(height: 18),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.15,
            children: [
              _QuickTile(icon: '📷', label: t('quickPhoto'),   accent: accent, onTap: () => goChat(intent: 'camera')),
              _QuickTile(icon: '🖼',  label: t('quickGallery'), accent: accent, onTap: () => goChat(intent: 'gallery')),
              _QuickTile(icon: '💬', label: t('quickChat'),    accent: accent, onTap: () => goChat()),
              _QuickTile(icon: '🍽', label: t('quickMeals'),   accent: accent, onTap: () => Navigator.pushReplacementNamed(context, '/meals')),
            ],
          ),
          if (recent.isNotEmpty) ...[
            const SizedBox(height: 26),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(t('recentProjects'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 14)),
              GestureDetector(
                onTap: () => Navigator.pushReplacementNamed(context, '/projects'),
                child: Text(t('seeAll'), style: TextStyle(color: accent.glow, fontSize: 12)),
              ),
            ]),
            const SizedBox(height: 10),
            ...recent.map((p) => _ProjectTile(project: p, accent: accent)),
          ],
        ]),
      ),
    );
  }
}

class _QuickTile extends StatelessWidget {
  final String icon, label;
  final ZAccent accent;
  final VoidCallback onTap;
  const _QuickTile({required this.icon, required this.label, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: ZColors.panel, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: ZColors.border),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: [accent.glow.withOpacity(0.13), accent.value.withOpacity(0.2)],
              ),
            ),
            child: Center(child: Text(icon, style: const TextStyle(fontSize: 20))),
          ),
          const SizedBox(height: 10),
          Text(label, style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 13)),
        ]),
      ),
    );
  }
}

class _ProjectTile extends StatelessWidget {
  final Project project;
  final ZAccent accent;
  const _ProjectTile({required this.project, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: ZColors.panel, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ZColors.border),
      ),
      child: Row(children: [
        Text(project.emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(project.title, style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 13.5)),
          Text('${project.data.total.calories.round()} kkal · ${project.data.total.score.round()} skor',
            style: const TextStyle(color: ZColors.faint, fontSize: 11.5)),
        ])),
        const Icon(Icons.chevron_right, color: ZColors.faint, size: 18),
      ]),
    );
  }
}
