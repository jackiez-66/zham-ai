import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';
import '../widgets/z_logo.dart';
import '../widgets/z_drawer.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final profile = state.profile!;
    final lang = profile.language;
    final t = (String k) => tr(lang, k);
    final planLabel = profile.plan == ZPlan.free ? t('planFree')
        : profile.plan == ZPlan.premium ? t('planPremium') : t('planPlus');

    return Scaffold(
      backgroundColor: ZColors.ink,
      drawer: const ZDrawer(currentRoute: '/profile'),
      appBar: AppBar(
        backgroundColor: ZColors.ink,
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: ZColors.ztext),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ZLogo(size: 22, accent: accent.value, glow: accent.glow),
          const SizedBox(width: 8),
          Text(t('profileTitle'), style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700)),
        ]),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(children: [
          Row(children: [
            const CircleAvatar(radius: 28, backgroundColor: ZColors.raised,
              child: Icon(Icons.person_outline, color: ZColors.dim, size: 28)),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${profile.firstName} ${profile.lastName}',
                style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700, fontSize: 16)),
              Text(profile.email, style: const TextStyle(color: ZColors.dim, fontSize: 12)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color: profile.plan == ZPlan.free ? ZColors.raised : accent.value,
                ),
                child: Text(planLabel,
                  style: TextStyle(
                    fontSize: 10.5, fontWeight: FontWeight.w600,
                    color: profile.plan == ZPlan.free ? ZColors.dim : Colors.white,
                  )),
              ),
            ]),
          ]),
          const SizedBox(height: 22),
          _Row(icon: Icons.mail_outline,     label: t('rowGmail'),    value: profile.email),
          _Row(icon: Icons.storage_outlined, label: t('rowStorage'),  value: '1.2 GB / 5 GB'),
          _Row(icon: Icons.work_outline,     label: t('rowWorkspace'), value: 'Personal'),
          _Row(icon: Icons.workspace_premium_outlined, label: t('rowUpgrade'),
            onTap: () => Navigator.pushReplacementNamed(context, '/premium')),
          _Row(icon: Icons.shield_outlined,  label: t('rowPrivacy'),
            onTap: () => state.showToast('Kontrol privasi akan tersedia di rilis berikutnya.')),
          _Row(icon: Icons.tune_outlined,    label: t('rowDataCtrl'),
            onTap: () => state.showToast('Kontrol data akan tersedia di rilis berikutnya.')),

          // Language
          Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: ZColors.border))),
            child: Row(children: [
              const Icon(Icons.language_outlined, color: ZColors.dim, size: 20),
              const SizedBox(width: 12),
              Expanded(child: Text(t('rowLang'), style: const TextStyle(color: ZColors.ztext, fontSize: 13.5))),
              DropdownButton<String>(
                value: profile.language,
                dropdownColor: ZColors.raised,
                underline: const SizedBox(),
                style: const TextStyle(color: ZColors.ztext, fontSize: 12),
                items: const [
                  DropdownMenuItem(value: 'id', child: Text('Indonesia')),
                  DropdownMenuItem(value: 'en', child: Text('English')),
                  DropdownMenuItem(value: 'ms', child: Text('Melayu')),
                  DropdownMenuItem(value: 'other', child: Text('Lainnya')),
                ],
                onChanged: (v) {
                  if (v != null) state.updateProfile(profile.copyWith(language: v));
                },
              ),
            ]),
          ),

          _Row(icon: Icons.mic_outlined,     label: t('rowVoice'),   value: 'Zham (Default)'),
          _Row(icon: Icons.dark_mode_outlined, label: t('rowTheme'), value: 'Gelap',
            onTap: () => state.showToast(t('themeSoon'))),

          // Accent swatches
          Container(
            padding: const EdgeInsets.symmetric(vertical: 13),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: ZColors.border))),
            child: Row(children: [
              const Icon(Icons.palette_outlined, color: ZColors.dim, size: 20),
              const SizedBox(width: 12),
              Expanded(child: Text(t('rowAccent'), style: const TextStyle(color: ZColors.ztext, fontSize: 13.5))),
              Row(children: kAccents.map((a) => GestureDetector(
                onTap: () {
                  state.updateProfile(profile.copyWith(accent: a.id));
                  state.showToast(t('toastAccent'));
                },
                child: Container(
                  width: 24, height: 24, margin: const EdgeInsets.only(left: 8),
                  decoration: BoxDecoration(
                    color: a.value, shape: BoxShape.circle,
                    border: Border.all(
                      color: profile.accent == a.id ? ZColors.ztext : Colors.transparent,
                      width: 2,
                    ),
                  ),
                ),
              )).toList()),
            ]),
          ),

          _Row(icon: Icons.logout_outlined, label: t('rowLogout'), onTap: () async {
            await state.logout();
          }),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  final VoidCallback? onTap;
  const _Row({required this.icon, required this.label, this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: ZColors.border))),
        child: Row(children: [
          Icon(icon, color: ZColors.dim, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(color: ZColors.ztext, fontSize: 13.5))),
          if (value != null) Text(value!, style: const TextStyle(color: ZColors.faint, fontSize: 12)),
          if (onTap != null) const SizedBox(width: 4),
          if (onTap != null) const Icon(Icons.chevron_right, color: ZColors.faint, size: 18),
        ]),
      ),
    );
  }
}
