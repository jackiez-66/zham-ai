import 'package:flutter/material.dart';
import '../theme.dart';
import '../i18n.dart';

Future<void> showPaywallDialog(BuildContext context, String lang, {required VoidCallback onUpgrade}) {
  final t = (String k) => tr(lang, k);
  return showDialog(
    context: context,
    builder: (ctx) {
      final accent = (ctx.findAncestorWidgetOfExactType<MaterialApp>() == null)
          ? kAccents.first : kAccents.first;
      return AlertDialog(
        backgroundColor: ZColors.panel,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 52, height: 52, decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: kAccents.first.value.withOpacity(0.2),
            ),
            child: Icon(Icons.lock_outline, color: kAccents.first.glow, size: 24),
          ),
          const SizedBox(height: 14),
          Text(t('paywallTitle'),
            style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w700, fontSize: 16),
            textAlign: TextAlign.center),
          const SizedBox(height: 10),
          Text(t('paywallBody'),
            style: const TextStyle(color: ZColors.dim, fontSize: 13, height: 1.6),
            textAlign: TextAlign.center),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kAccents.first.value,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 13),
              ),
              onPressed: () { Navigator.pop(ctx); onUpgrade(); },
              child: Text(t('paywallCta'), style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(t('paywallLater'), style: const TextStyle(color: ZColors.faint, fontSize: 12.5)),
          ),
        ]),
      );
    },
  );
}
