import 'package:flutter/material.dart';

class ZLogo extends StatelessWidget {
  final double size;
  final Color accent;
  final Color glow;
  const ZLogo({super.key, this.size = 36, required this.accent, required this.glow});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _ZLogoPainter(accent: accent, glow: glow),
    );
  }
}

class _ZLogoPainter extends CustomPainter {
  final Color accent, glow;
  _ZLogoPainter({required this.accent, required this.glow});

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width;
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, s, s),
      Radius.circular(s * 0.27),
    );
    // Background
    canvas.drawRRect(rrect, Paint()..color = const Color(0xFF161617));
    canvas.drawRRect(rrect, Paint()
      ..color = const Color(0xFF2B2B2E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = s * 0.02);

    // Z stroke with gradient
    final zPaint = Paint()
      ..shader = LinearGradient(colors: [glow, accent]).createShader(Rect.fromLTWH(0, 0, s, s))
      ..strokeWidth = s * 0.075
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    final path = Path()
      ..moveTo(s * 0.29, s * 0.31)
      ..lineTo(s * 0.65, s * 0.31)
      ..lineTo(s * 0.35, s * 0.67)
      ..lineTo(s * 0.71, s * 0.67);
    canvas.drawPath(path, zPaint);

    // AI neuron dots
    final dotPaint = Paint()..color = glow;
    canvas.drawCircle(Offset(s * 0.47, s * 0.49), s * 0.030, dotPaint);
    canvas.drawCircle(Offset(s * 0.40, s * 0.56), s * 0.022, Paint()..color = accent);
    canvas.drawCircle(Offset(s * 0.53, s * 0.43), s * 0.022, Paint()..color = accent);
  }

  @override
  bool shouldRepaint(_ZLogoPainter old) => old.accent != accent || old.glow != glow;
}
