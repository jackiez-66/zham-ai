import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme.dart';
import '../i18n.dart';
import '../models.dart';
import 'z_logo.dart';

class ZDrawer extends StatelessWidget {
  final String currentRoute;
  const ZDrawer({super.key, required this.currentRoute});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final accent = state.accent;
    final profile = state.profile!;
    final lang = profile.language;
    final t = (String k) => tr(lang, k);

    final items = [
      _NavItem(key: '/home',     label: t('navHome'),     icon: Icons.home_outlined),
      _NavItem(key: '/chat',     label: t('navNewChat'),  icon: Icons.add_comment_outlined),
      _NavItem(key: '/projects', label: t('navProjects'), icon: Icons.folder_outlined),
      _NavItem(key: '/premium',  label: t('navPremium'),  icon: Icons.workspace_premium_outlined),
      _NavItem(key: '/profile',  label: t('navProfile'),  icon: Icons.person_outline),
    ];

    final planLabel = profile.plan == ZPlan.free ? t('planFree')
        : profile.plan == ZPlan.premium ? t('planPremium') : t('planPlus');

    return Drawer(
      backgroundColor: ZColors.panel,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(children: [
                CircleAvatar(
                  radius: 20, backgroundColor: ZColors.raised,
                  child: const Icon(Icons.person_outline, color: ZColors.dim, size: 20),
                ),
                const SizedBox(width: 10),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${profile.firstName} ${profile.lastName}',
                    style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 14)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(999),
                      color: profile.plan == ZPlan.free ? ZColors.raised : accent.value,
                    ),
                    child: Text(planLabel,
                      style: TextStyle(
                        fontSize: 10.5, fontWeight: FontWeight.w600,
                        color: profile.plan == ZPlan.free ? ZColors.dim : Colors.white,
                      )),
                  ),
                ]),
              ]),
            ),
            const Divider(color: ZColors.border, height: 24),
            ...items.map((item) {
              final active = currentRoute == item.key;
              return ListTile(
                leading: Icon(item.icon, color: active ? accent.glow : ZColors.dim, size: 20),
                title: Text(item.label, style: TextStyle(
                  color: active ? ZColors.ztext : ZColors.dim,
                  fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                  fontSize: 14,
                )),
                tileColor: active ? ZColors.raised : Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                onTap: () {
                  Navigator.pop(context);
                  if (currentRoute != item.key) Navigator.pushReplacementNamed(context, item.key);
                },
              );
            }),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('Zham.AI v1.0', style: const TextStyle(color: ZColors.faint, fontSize: 11)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  final String key, label;
  final IconData icon;
  _NavItem({required this.key, required this.label, required this.icon});
}
