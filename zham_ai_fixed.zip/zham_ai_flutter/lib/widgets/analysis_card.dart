import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../models.dart';
import '../theme.dart';
import '../i18n.dart';

class AnalysisCard extends StatelessWidget {
  final NutritionResult data;
  final ZAccent accent;
  final String lang;
  const AnalysisCard({super.key, required this.data, required this.accent, required this.lang});

  @override
  Widget build(BuildContext context) {
    final t = (String k) => tr(lang, k);
    return Container(
      decoration: BoxDecoration(
        color: ZColors.panel, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ZColors.border),
      ),
      padding: const EdgeInsets.all(14),
      child: data.items.isEmpty
          ? Text(data.assessment, style: const TextStyle(color: ZColors.dim, fontSize: 13))
          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ...data.items.asMap().entries.map((e) => _ItemRow(
                item: e.value,
                isLast: e.key == data.items.length - 1,
              )),
              const SizedBox(height: 14),
              Text(t('totalSummary').toUpperCase(),
                style: const TextStyle(color: ZColors.dim, fontSize: 11, letterSpacing: 0.8)),
              const SizedBox(height: 10),
              Row(children: [
                _ScoreRing(score: data.total.score.round(), accent: accent),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t('score'), style: const TextStyle(color: ZColors.faint, fontSize: 10.5)),
                  Text('${data.total.score.round()} / 100',
                    style: const TextStyle(color: ZColors.ztext, fontSize: 13)),
                ]),
              ]),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 2.4,
                children: [
                  _NutStat(label: '🔥 ${t("calories")}', value: '${data.total.calories.round()} kkal'),
                  _NutStat(label: '💪 ${t("protein")}',  value: '${data.total.proteinG.round()}g'),
                  _NutStat(label: '🥑 ${t("fat")}',      value: '${data.total.fatG.round()}g'),
                  _NutStat(label: '🌾 ${t("carbs")}',    value: '${data.total.carbsG.round()}g'),
                  _NutStat(label: '💧 ${t("water")}',    value: '${data.total.waterMl.round()}ml'),
                  _NutStat(label: '🩸 ${t("minerals")}', value: '${data.total.minerals.length} jenis'),
                ],
              ),
              if (data.total.vitamins.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(spacing: 6, runSpacing: 6, children: data.total.vitamins.map((v) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: ZColors.raised, borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text('🧬 $v', style: TextStyle(color: accent.glow, fontSize: 11)),
                )).toList()),
              ],
              const SizedBox(height: 14),
              const Divider(color: ZColors.border, height: 1),
              const SizedBox(height: 10),
              Row(children: [
                Icon(Icons.auto_awesome, color: accent.glow, size: 14),
                const SizedBox(width: 6),
                Text(t('aiAssessment').toUpperCase(),
                  style: const TextStyle(color: ZColors.dim, fontSize: 11, letterSpacing: 0.8)),
              ]),
              const SizedBox(height: 6),
              Text(data.assessment,
                style: const TextStyle(color: ZColors.ztext, fontSize: 13, height: 1.55,
                  fontStyle: FontStyle.italic)),
            ]),
    );
  }
}

class _ItemRow extends StatelessWidget {
  final NutritionItem item;
  final bool isLast;
  const _ItemRow({required this.item, required this.isLast});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        border: isLast ? null : const Border(bottom: BorderSide(color: ZColors.border)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(item.emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.name, style: const TextStyle(color: ZColors.ztext, fontWeight: FontWeight.w600, fontSize: 13.5)),
          Text(item.notes, style: const TextStyle(color: ZColors.faint, fontSize: 11.5)),
        ])),
        Text('${item.calories.round()} kkal',
          style: const TextStyle(color: ZColors.ztext, fontSize: 13, fontFeatures: [FontFeature.tabularFigures()])),
      ]),
    );
  }
}

class _NutStat extends StatelessWidget {
  final String label, value;
  const _NutStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: ZColors.raised, borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: ZColors.faint, fontSize: 10.5)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(color: ZColors.ztext, fontSize: 13, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _ScoreRing extends StatelessWidget {
  final int score;
  final ZAccent accent;
  const _ScoreRing({required this.score, required this.accent});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(60, 60),
      painter: _RingPainter(score: score, accent: accent),
      child: SizedBox(
        width: 60, height: 60,
        child: Center(child: Text('$score',
          style: const TextStyle(color: ZColors.ztext, fontSize: 15, fontWeight: FontWeight.w700))),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final int score;
  final ZAccent accent;
  _RingPainter({required this.score, required this.accent});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    canvas.drawCircle(center, radius, Paint()
      ..color = ZColors.border ..style = PaintingStyle.stroke ..strokeWidth = 5);
    final sweep = 2 * math.pi * score / 100;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2, sweep, false,
      Paint()
        ..color = accent.glow
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round,
    );
  }
  @override
  bool shouldRepaint(_RingPainter old) => old.score != score;
}
