import 'package:flutter/material.dart';
import 'models.dart';
import 'services/storage_service.dart';
import 'services/ai_service.dart';
import 'theme.dart';

class AppState extends ChangeNotifier {
  final _storage = StorageService();
  final _ai = AIService();

  UserProfile? profile;
  DailyUsage usage = DailyUsage(date: '', count: 0);
  List<Project> projects = [];
  MealPlan? meals;
  bool booted = false;
  String? toastMessage;

  ZAccent get accent => accentById(profile?.accent ?? 'maroon');

  // ── Boot ────────────────────────────────────────────────────────────────────
  Future<void> boot() async {
    profile  = await _storage.getProfile();
    usage    = await _storage.getUsage();
    projects = await _storage.getProjects();
    meals    = await _storage.getMeals();
    booted   = true;
    notifyListeners();
  }

  // ── Auth ────────────────────────────────────────────────────────────────────
  Future<void> login(UserProfile p) async {
    profile = p;
    await _storage.setProfile(p);
    notifyListeners();
  }

  Future<void> logout() async {
    await _storage.clearProfile();
    profile = null;
    notifyListeners();
  }

  // ── Usage / Paywall ─────────────────────────────────────────────────────────
  bool canInteract() {
    if (profile == null || profile!.plan != ZPlan.free) return true;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (usage.date != today) return true;
    return usage.count < 3;
  }

  Future<void> registerInteraction() async {
    if (profile == null || profile!.plan != ZPlan.free) return;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    usage = usage.date == today
        ? DailyUsage(date: today, count: usage.count + 1)
        : DailyUsage(date: today, count: 1);
    await _storage.setUsage(usage);
    notifyListeners();
  }

  // ── Profile updates ─────────────────────────────────────────────────────────
  Future<void> updateProfile(UserProfile p) async {
    profile = p;
    await _storage.setProfile(p);
    notifyListeners();
  }

  Future<void> upgrade(ZPlan plan) async {
    if (profile == null) return;
    await updateProfile(profile!.copyWith(plan: plan));
    showToast(plan == ZPlan.premium ? '✓ Kamu sekarang Premium!' : '✓ Kamu sekarang Premium Plus!');
  }

  // ── Analysis ────────────────────────────────────────────────────────────────
  Future<NutritionResult> analyzeText(String text) =>
      _ai.analyzeText(text, profile?.language ?? 'id');

  Future<NutritionResult> analyzeImage(List<int> bytes, String mime) =>
      _ai.analyzeImage(bytes as dynamic, mime, profile?.language ?? 'id');

  Future<void> saveProject(NutritionResult result) async {
    final items = result.items;
    final title = items.isNotEmpty
        ? items.take(2).map((e) => e.name).join(' & ')
        : 'Analisis Makanan';
    final project = Project(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      date: DateTime.now().toIso8601String(),
      emoji: items.isNotEmpty ? items.first.emoji : '🍽',
      data: result,
    );
    projects = [project, ...projects];
    await _storage.setProjects(projects);
    notifyListeners();
  }

  // ── Meals ────────────────────────────────────────────────────────────────────
  Future<void> generateMealPlan() async {
    final plan = await _ai.generateMealPlan(profile?.language ?? 'id');
    meals = plan;
    await _storage.setMeals(plan);
    notifyListeners();
  }

  Future<void> setMeals(MealPlan plan) async {
    meals = plan;
    await _storage.setMeals(plan);
    notifyListeners();
  }

  // ── Toast ────────────────────────────────────────────────────────────────────
  void showToast(String msg) {
    toastMessage = msg;
    notifyListeners();
    Future.delayed(const Duration(milliseconds: 2600), () {
      toastMessage = null;
      notifyListeners();
    });
  }
}
