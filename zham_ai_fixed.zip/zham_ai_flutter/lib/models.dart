import 'dart:convert';

enum ZPlan { free, premium, premiumPlus }

ZPlan planFromString(String? s) {
  switch (s) {
    case 'premium':      return ZPlan.premium;
    case 'premium_plus': return ZPlan.premiumPlus;
    default:             return ZPlan.free;
  }
}
String planToString(ZPlan p) {
  switch (p) {
    case ZPlan.premium:     return 'premium';
    case ZPlan.premiumPlus: return 'premium_plus';
    case ZPlan.free:        return 'free';
  }
}

class UserProfile {
  final String firstName, lastName, email, language, accent;
  final ZPlan plan;
  const UserProfile({
    required this.firstName, required this.lastName,
    required this.email,
    this.language = 'id', this.plan = ZPlan.free, this.accent = 'maroon',
  });
  UserProfile copyWith({String? firstName, String? lastName, String? email,
    String? language, ZPlan? plan, String? accent}) => UserProfile(
    firstName: firstName ?? this.firstName, lastName: lastName ?? this.lastName,
    email: email ?? this.email, language: language ?? this.language,
    plan: plan ?? this.plan, accent: accent ?? this.accent,
  );
  Map<String,dynamic> toJson() => {
    'firstName': firstName, 'lastName': lastName, 'email': email,
    'language': language, 'plan': planToString(plan), 'accent': accent,
  };
  factory UserProfile.fromJson(Map<String,dynamic> j) => UserProfile(
    firstName: j['firstName'] ?? '', lastName: j['lastName'] ?? '',
    email: j['email'] ?? '', language: j['language'] ?? 'id',
    plan: planFromString(j['plan']), accent: j['accent'] ?? 'maroon',
  );
}

class DailyUsage {
  final String date;
  final int count;
  const DailyUsage({required this.date, required this.count});
  Map<String,dynamic> toJson() => {'date': date, 'count': count};
  factory DailyUsage.fromJson(Map<String,dynamic> j) =>
      DailyUsage(date: j['date'] ?? '', count: (j['count'] ?? 0) as int);
}

class NutritionItem {
  final String emoji, name, notes;
  final double calories, proteinG, carbsG, fatG, cholesterolMg;
  NutritionItem({required this.emoji, required this.name, required this.notes,
    required this.calories, required this.proteinG, required this.carbsG,
    required this.fatG, required this.cholesterolMg});
  factory NutritionItem.fromJson(Map<String,dynamic> j) => NutritionItem(
    emoji: j['emoji'] ?? '🍽', name: j['name'] ?? '', notes: j['notes'] ?? '',
    calories: (j['calories'] ?? 0).toDouble(), proteinG: (j['protein_g'] ?? 0).toDouble(),
    carbsG: (j['carbs_g'] ?? 0).toDouble(), fatG: (j['fat_g'] ?? 0).toDouble(),
    cholesterolMg: (j['cholesterol_mg'] ?? 0).toDouble(),
  );
  Map<String,dynamic> toJson() => {
    'emoji': emoji, 'name': name, 'notes': notes, 'calories': calories,
    'protein_g': proteinG, 'carbs_g': carbsG, 'fat_g': fatG, 'cholesterol_mg': cholesterolMg,
  };
}

class NutritionTotal {
  final double calories, proteinG, carbsG, fatG, waterMl, score;
  final List<String> minerals, vitamins;
  NutritionTotal({required this.calories, required this.proteinG, required this.carbsG,
    required this.fatG, required this.waterMl, required this.score,
    required this.minerals, required this.vitamins});
  factory NutritionTotal.fromJson(Map<String,dynamic> j) => NutritionTotal(
    calories: (j['calories'] ?? 0).toDouble(), proteinG: (j['protein_g'] ?? 0).toDouble(),
    carbsG: (j['carbs_g'] ?? 0).toDouble(), fatG: (j['fat_g'] ?? 0).toDouble(),
    waterMl: (j['water_ml'] ?? 0).toDouble(), score: (j['score'] ?? 0).toDouble(),
    minerals: List<String>.from(j['minerals'] ?? []),
    vitamins: List<String>.from(j['vitamins'] ?? []),
  );
  Map<String,dynamic> toJson() => {
    'calories': calories, 'protein_g': proteinG, 'carbs_g': carbsG,
    'fat_g': fatG, 'water_ml': waterMl, 'score': score,
    'minerals': minerals, 'vitamins': vitamins,
  };
}

class NutritionResult {
  final List<NutritionItem> items;
  final NutritionTotal total;
  final String assessment;
  NutritionResult({required this.items, required this.total, required this.assessment});
  factory NutritionResult.fromJson(Map<String,dynamic> j) => NutritionResult(
    items: (j['items'] as List? ?? []).map((e) => NutritionItem.fromJson(e as Map<String,dynamic>)).toList(),
    total: NutritionTotal.fromJson(j['total'] ?? {}),
    assessment: j['assessment'] ?? '',
  );
  Map<String,dynamic> toJson() => {
    'items': items.map((e) => e.toJson()).toList(),
    'total': total.toJson(), 'assessment': assessment,
  };
}

class Project {
  final String id, title, date, emoji;
  final NutritionResult data;
  Project({required this.id, required this.title, required this.date,
    required this.emoji, required this.data});
  Map<String,dynamic> toJson() => {
    'id': id, 'title': title, 'date': date, 'emoji': emoji, 'data': data.toJson(),
  };
  factory Project.fromJson(Map<String,dynamic> j) => Project(
    id: j['id'] ?? '', title: j['title'] ?? '', date: j['date'] ?? '',
    emoji: j['emoji'] ?? '🍽', data: NutritionResult.fromJson(j['data'] ?? {}),
  );
}

class MealEntry {
  final String time, name;
  final double calories;
  MealEntry({required this.time, required this.name, required this.calories});
  factory MealEntry.fromJson(Map<String,dynamic> j) => MealEntry(
    time: j['time'] ?? '', name: j['name'] ?? '', calories: (j['calories'] ?? 0).toDouble(),
  );
  Map<String,dynamic> toJson() => {'time': time, 'name': name, 'calories': calories};
}

class MealDay {
  final String day;
  final List<MealEntry> meals;
  MealDay({required this.day, required this.meals});
  factory MealDay.fromJson(Map<String,dynamic> j) => MealDay(
    day: j['day'] ?? '',
    meals: (j['meals'] as List? ?? []).map((e) => MealEntry.fromJson(e as Map<String,dynamic>)).toList(),
  );
  Map<String,dynamic> toJson() => {'day': day, 'meals': meals.map((e) => e.toJson()).toList()};
}

class MealPlan {
  final List<MealDay> days;
  final String note;
  MealPlan({required this.days, required this.note});
  static const weekDays = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'];
  factory MealPlan.emptyWeek() =>
      MealPlan(days: weekDays.map((d) => MealDay(day: d, meals: [])).toList(), note: '');
  factory MealPlan.fromJson(Map<String,dynamic> j) => MealPlan(
    days: (j['days'] as List? ?? []).map((e) => MealDay.fromJson(e as Map<String,dynamic>)).toList(),
    note: j['note'] ?? '',
  );
  Map<String,dynamic> toJson() => {'days': days.map((e) => e.toJson()).toList(), 'note': note};
}
